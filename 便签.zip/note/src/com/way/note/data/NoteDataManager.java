package com.way.note.data;

import java.util.List;

import android.content.Context;

/**
 * ��ǩ����
 * 
 * @author way
 * 
 */
public interface NoteDataManager {

	public void initData(Context context);// ��ʼ������

	public List<NoteItem> getFolderAndAllItems();// ��ȡ�����ļ��к����б�ǩ

	public NoteItem getNoteItem(int id);// ͨ��id��ȡͨ��id

	public NoteItem getNoteItemFromDB(int id);

	public int insertItem(NoteItem item);

	public int updateItem(NoteItem item);

	public List<NoteItem> getFolders();

	/**
	 * get notes, not include note forld.
	 */
	public List<NoteItem> getNotes();

	public List<NoteItem> getRootFoldersAndNotes();

	public List<NoteItem> getRootNotes();

	public List<NoteItem> getNotesFromFolder(int folderID);

	public void deleteNoteItem(NoteItem item);

	public void deleteAllNotes();

	public List<NoteItem> getColckAlarmItems();

	public List<NoteItem> getNotesIncludeContent(String content);

	public List<NoteItem> getColckAlarmItemsFromDB();
}
