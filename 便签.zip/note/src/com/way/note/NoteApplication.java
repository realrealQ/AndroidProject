package com.way.note;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.way.note.data.NoteDataManager;
import com.way.note.data.NoteDataManagerImpl;

/**
 * �Զ���Application������ȫ�ֱ���
 * 
 * @author way
 * 
 */
public class NoteApplication extends Application {
	private static final String TAG = "NoteApplication";

	NoteDataManager mDataManager = null;// ��ǩ��������

	public synchronized NoteDataManager getNoteDataManager(Context context) {
		if (mDataManager == null) {
			mDataManager = NoteDataManagerImpl.getNoteDataManger(context);
			mDataManager.initData(context);
		}
		return mDataManager;
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
		Log.i(TAG, "onTerminate");
	}
}
