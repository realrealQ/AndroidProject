package com.way.note;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.way.note.data.NoteItem;
import com.way.note.data.RingtoneItem;
import com.way.note.utils.ClockUtils;

/**
 * 
 * @author way
 * 
 */
public class AlarmActivity extends BaseActivity implements OnItemClickListener,
		DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener {
	private static final String TAG = "AlarmActivity";

	public static final String NOTE_ID = "noteID";

	private ListView mListView;
	private List<String> mItems = null;
	private List<String> mValues = new ArrayList<String>();
	private NoteItem noteItem = null;
	private AlarmSettingAdapter adapter = null;

	private Calendar cal = Calendar.getInstance();

	String mExternal = "content://media/external/";

	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.alarm_layout);
		Log.v(TAG, "onCreate()  intent-->" + getIntent() + "  data-->"
				+ (getIntent() == null ? "" : getIntent().getExtras()));
		initViews();
		if (!initDataSuccess()) {
			finish();
		}
	}

	private void initViews() {
		mListView = (ListView) findViewById(R.id.alarm_listview);
		mListView.setOnItemClickListener(this);
	}

	private boolean initDataSuccess() {
		int noteID = getIntent().getIntExtra(NOTE_ID, -1);
		Log.v(TAG, "initDataSuccess ID-->" + noteID);
		if (noteID == -1) {
			return false;
		}

		noteItem = getDataManager(this).getNoteItem(noteID);
		Log.v(TAG, "initDataSuccess noteItem-->" + noteItem);
		// fix for bug 74169 start
		if (noteItem == null) {
			return false;
		}
		// fix for bug 71469 end

		String ringtoneUrl = noteItem.clockItem.ringtoneUrl;

		if (ringtoneUrl != null && ringtoneUrl.startsWith(mExternal)) {
			if (!ClockUtils.isSongExist(this, ringtoneUrl)) {
				noteItem.clockItem.ringtoneUrl = RingtoneItem.DEFAULT_RINGTONE;
			}
		}

		String[] itemsStrArray = getResources().getStringArray(
				R.array.clock_items);
		mItems = Arrays.asList(itemsStrArray);
		return true;
	}

	@Override
	public void onResume() {
		Log.v(TAG, "onResume()");
		super.onResume();
		updateData();
		updateDisplay();
	}

	private void updateData() {
		mValues.clear();
		if (noteItem.alarmEnable) {
			mValues.add(getResources().getString(R.string.yes));
		} else {
			mValues.add(getResources().getString(R.string.no));
		}

		try {
			Date date = noteItem.clockItem.getClockDate();
			mValues.add(DateFormat.getDateFormat(this).format(date));
		} catch (ParseException e) {
			Log.e(TAG, e.getMessage());
			mValues.add("");
		}

		// mValues.add(noteItem.clockItem.ringtoneDate); // format: 2002-02-13

		try {
			Date time = noteItem.clockItem.getClockTime();
			mValues.add(DateFormat.getTimeFormat(this).format(time));
		} catch (ParseException e) {
			Log.e(TAG, e.getMessage());
			mValues.add("");
		}

		if (noteItem.clockItem.isVibrate) {
			mValues.add(getResources().getString(R.string.yes));
		} else {
			mValues.add(getResources().getString(R.string.no));
		}

		if (noteItem.clockItem.ringtoneName
				.equals(RingtoneItem.DEFAULT_RINGTONE)) {
			mValues.add(getResources().getString(R.string.default_rings_name));
		} else {
			mValues.add(noteItem.clockItem.ringtoneName);
		}
		Log.v(TAG, "updateDate values-->" + mValues);
	}

	private void updateDisplay() {
		if (adapter == null) {
			adapter = new AlarmSettingAdapter(this, mItems, mValues);
			mListView.setAdapter(adapter);
		} else {
			adapter.updateItem(mValues);
			adapter.notifyDataSetChanged();
		}
	}

	private void updateUI() {
		updateData();
		updateDisplay();
	}

	public void onPause() {
		super.onPause();
		Log.i(TAG, "OnPause");
	}

	public void setRings() {
		Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
		intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,
				RingtoneManager.TYPE_ALARM);
		intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE,
		// R.string.set_alarm_ringtone);
				getResources().getString(R.string.set_alarm_ringtone));

		// Allow user to pick 'Default'
		intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
		// show 'Silent'
		intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);

		String urlStr = noteItem.clockItem.ringtoneUrl;
		Uri ringtoneUri = null;
		if (urlStr == null) { // silent
			ringtoneUri = null;
		} else if (!urlStr.equals(RingtoneItem.DEFAULT_RINGTONE)) { // default
			ringtoneUri = Uri.parse(urlStr);
		} else {
			// Otherwise pick default ringtone Uri so that something is
			// selected.
			ringtoneUri = RingtoneManager
					.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
		}
		intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
				ringtoneUri);
		Log.i(TAG,
				"setRings intent-->" + intent + "  data-->"
						+ intent.getExtras());
		this.startActivityForResult(intent, 1);
	}

	/*
	 * protected Uri onRestoreRingtone(int mRingtoneType) { Uri actualUri =
	 * RingtoneManager.getActualDefaultRingtoneUri(this, mRingtoneType);
	 * Log.i("URL", actualUri.getPath() + " "); return actualUri != null ?
	 * actualUri : null; }
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.i(TAG, "onActivityResult requestCode-->" + requestCode
				+ "  resultCode-->" + resultCode);
		Log.i(TAG, "onActivityResult intent-->" + data + "  data-->"
				+ (data == null ? null : data.getExtras()));
		if (resultCode != RESULT_OK) {
			return;
		}

		if (requestCode == 1) {
			try {
				// Uri uri = data!=null ? data.getData() : null;
				// 得到我们选择的铃声
				Uri uri = data
						.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
				// 将我们选择的铃声选择成默认
				if (uri != null) {
					noteItem.clockItem.ringtoneUrl = uri.toString();
					Log.v("you", "rings_uri= " + uri.toString()
							+ " **********************************");
					if (RingtoneManager.isDefault(uri)) {
						noteItem.clockItem.ringtoneName = RingtoneItem.DEFAULT_RINGTONE;
					} else {
						// 通过uri查询闹铃文件
						Cursor cursor = this.getContentResolver().query(uri,
								ClockUtils.CURSOR_COLS, null, null, null);
						cursor.moveToFirst();
						// 显示的闹钟铃声
						String rings_name = cursor
								.getString(cursor
										.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME));
						cursor.close();
						Log.v("you", "rings_name= " + rings_name);
						noteItem.clockItem.ringtoneName = rings_name.substring(
								0, rings_name.lastIndexOf("."))/*
																 * .toLowerCase()
																 */;
					}
				} else {
					noteItem.clockItem.ringtoneName = getResources().getString(
							R.string.silent);
					noteItem.clockItem.ringtoneUrl = null;
				}
				saveChange();
				updateUI();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	public void saveChange() {
		getDataManager(this).updateItem(noteItem);
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position,
			long arg3) {
		switch (position) {
		case 0:
			setAlarmState();
			break;
		case 1:
			setDate();
			break;
		case 2:
			setTime();
			break;
		case 3:
			setVibrate();
			break;
		case 4:
			setRings();
			break;
		}
	}

	private void setAlarmState() {
		String[] choices = new String[] {
				getResources().getString(R.string.yes),
				getResources().getString(R.string.no) };

		AlertDialog.Builder builder = new AlertDialog.Builder(
				AlarmActivity.this)
				.setTitle(R.string.enableAlarm)
				// .setItems(yesOrNo, listener)
				.setSingleChoiceItems(choices, noteItem.alarmEnable ? 0 : 1,
						openAlarmlistener)
				.setNegativeButton(R.string.Cancel, cancelDialog);
		builder.show();
	}

	OnClickListener openAlarmlistener = new DialogInterface.OnClickListener() {
		@Override
		public void onClick(DialogInterface dialog, int which) {
			switch (which) {
			case 0:
				setAlarm();
				updateUI();
				break;
			case 1:
				closeAlarm();
				break;
			}
			dialog.dismiss();
			// saveChange();
		}
	};

	private boolean setAlarm() {
		if (isIllegelTime()) {
			return false;
		}
		if (isSameTimeClock()) {
			return false;
		}

		noteItem.alarmEnable = true;
		saveChange();
		ClockUtils.cancleAlarmClock(this, noteItem);
		ClockUtils.setAlarmClock(this, noteItem);
		return true;
	}

	// 查询所有便簽鬧鈴date和time，如果存在和当前設置日期时间一样，那么不允许开启该鬧鈴，并提示用户。
	private boolean isSameTimeClock() {
		String date_setted = noteItem.clockItem.ringtoneDate;
		String time_setted = noteItem.clockItem.ringtoneTime;

		List<NoteItem> colckAlarmItems = getDataManager(this)
				.getColckAlarmItems();
		colckAlarmItems.remove(noteItem); // remove itself if exist.
		for (NoteItem clockItems : colckAlarmItems) {
			String old_date = clockItems.clockItem.ringtoneDate;
			String old_time = clockItems.clockItem.ringtoneTime;
			if (old_date.equals(date_setted) && old_time.equals(time_setted)) {
				Toast.makeText(AlarmActivity.this, R.string.date_time_setted,
						Toast.LENGTH_LONG).show();
				return true;
			}
		}
		return false;
	}

	private boolean isIllegelTime() {
		if (isDateNull() && isTimeNull()) {
			Toast.makeText(this, R.string.set_date_and_time_frist, 1000).show();
			return true;
		} else if (isDateNull()) {
			Toast.makeText(this, R.string.set_date_frist, 1000).show();
			return true;
		} else if (isTimeNull()) {
			Toast.makeText(this, R.string.set_time_frist, 1000).show();
			return true;
		}

		// 将以字符串形式的时间设到闹钟服务中
		String[] temp = noteItem.clockItem.ringtoneTime.split(":");
		Calendar dateCalendar = praseDate();

		dateCalendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(temp[0]));
		dateCalendar.set(Calendar.MINUTE, Integer.parseInt(temp[1]));
		dateCalendar.set(Calendar.SECOND, 0);
		dateCalendar.set(Calendar.MILLISECOND, 0);

		/**
		 * add one getoff alarm,system raise alarm ; if it is timeout, system
		 * must not set alarm and notify user change time yu.li@spreadtrum.com
		 * 2012/04/16 CR00561254
		 */
		if (dateCalendar.getTime().getTime() - System.currentTimeMillis() < 0) {
			Toast.makeText(AlarmActivity.this, R.string.alarm_time_error,
					Toast.LENGTH_LONG).show();
			return true;
		}
		return false;
	}

	public boolean isDateNull() {
		return noteItem.clockItem.ringtoneDate == null
				|| noteItem.clockItem.ringtoneDate.length() == 0;
	}

	public boolean isTimeNull() {
		return noteItem.clockItem.ringtoneTime == null
				|| noteItem.clockItem.ringtoneTime.length() == 0;
	}

	private void closeAlarm() {
		// cancle alarm
		ClockUtils.cancleAlarmClock(this, noteItem);

		// update db and cache
		noteItem.alarmEnable = false;
		saveChange();

		// update displays
		updateUI();
	}

	private void setDate() {
		Calendar calendar = null;

		if (noteItem.clockItem.ringtoneDate.length() == 0) {
			calendar = Calendar.getInstance();
			cal.setTimeInMillis(System.currentTimeMillis());
		} else {
			calendar = praseDate();
		}

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		new DatePickerDialog(AlarmActivity.this, this, year, month, day).show();
	}

	private Calendar praseDate() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date settingDate = dateFormat
					.parse(noteItem.clockItem.ringtoneDate);
			Calendar settingCal = Calendar.getInstance();
			settingCal.setTime(settingDate);
			return settingCal;
		} catch (ParseException e) {
			Log.e(TAG, "setDate fail!!!");
		}

		return null;
	}

	private Calendar praseTime() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
		try {
			Date settingDate = dateFormat
					.parse(noteItem.clockItem.ringtoneTime);
			Calendar settingCal = Calendar.getInstance();
			settingCal.setTime(settingDate);
			return settingCal;
		} catch (ParseException e) {
			Log.e(TAG, "setTime fail!!!");
		}

		return null;
	}

	@Override
	public void onDateSet(DatePicker view, int year, int monthOfYear,
			int dayOfMonth) {
		Calendar calendar = praseTime();
		if (calendar != null) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, monthOfYear);
			calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
				Toast.makeText(getApplicationContext(),
						R.string.alarm_time_error, Toast.LENGTH_LONG).show();
				return;
			}
		} else { // 如果没有设置时间，日期只能设置为当天或者以后
			cal.setTimeInMillis(System.currentTimeMillis());
			int cur_year = cal.get(Calendar.YEAR);
			int cur_month = cal.get(Calendar.MONTH);
			int cur_day = cal.get(Calendar.DAY_OF_MONTH);

			Calendar sys_current = Calendar.getInstance();
			sys_current.set(Calendar.YEAR, cur_year);
			sys_current.set(Calendar.MONTH, cur_month);
			sys_current.set(Calendar.DAY_OF_MONTH, cur_day);
			sys_current.set(Calendar.HOUR_OF_DAY, 0);
			sys_current.set(Calendar.MINUTE, 0);

			Calendar set_date = Calendar.getInstance();
			set_date.set(Calendar.YEAR, year);
			set_date.set(Calendar.MONTH, monthOfYear);
			set_date.set(Calendar.DAY_OF_MONTH, dayOfMonth);
			set_date.set(Calendar.HOUR_OF_DAY, 0);
			set_date.set(Calendar.MINUTE, 0);

			if (set_date.getTimeInMillis() < sys_current.getTimeInMillis()) {
				Toast.makeText(getApplicationContext(),
						R.string.alarm_time_error, Toast.LENGTH_LONG).show();
				return;
			}
		}

		String oldDate = noteItem.clockItem.ringtoneDate;
		noteItem.clockItem.ringtoneDate = year + "-" + format(monthOfYear + 1)
				+ "-" + format(dayOfMonth);

		if (noteItem.alarmEnable) {
			if (setAlarm()) {
				updateUI();
				saveChange();
			} else {
				noteItem.clockItem.ringtoneDate = oldDate;
			}
		} else {
			updateUI();
			saveChange();
		}
	}

	// 将int类型转化为string
	public String format(int i) {
		String s = "" + i;
		if (s.length() == 1)
			s = "0" + s;
		return s;
	}

	private void setTime() {
		int hour = 0;
		int minute = 0;
		cal.setTimeInMillis(System.currentTimeMillis());
		hour = cal.get(Calendar.HOUR_OF_DAY);
		minute = cal.get(Calendar.MINUTE);

		if (noteItem.clockItem.ringtoneTime.length() == 0) {
			cal.setTimeInMillis(System.currentTimeMillis());
			hour = cal.get(Calendar.HOUR_OF_DAY);
			minute = cal.get(Calendar.MINUTE);
		} else {
			Calendar calendar = praseTime();
			if (calendar != null) {
				hour = calendar.get(Calendar.HOUR_OF_DAY);
				minute = calendar.get(Calendar.MINUTE);
			}
		}
		new TimePickerDialog(AlarmActivity.this, this, hour, minute,
				DateFormat.is24HourFormat(this)).show();
	}

	@Override
	public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		Calendar calendar = praseDate();
		if (calendar != null) {
			calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
			calendar.set(Calendar.MINUTE, minute);
			if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
				Toast.makeText(getApplicationContext(),
						R.string.alarm_time_error, Toast.LENGTH_LONG).show();
				return;
			}
		}

		String oldTime = noteItem.clockItem.ringtoneTime;
		noteItem.clockItem.ringtoneTime = format(hourOfDay) + ":"
				+ format(minute);

		if (noteItem.alarmEnable) {
			if (setAlarm()) {
				updateUI();
				saveChange();
			} else {
				noteItem.clockItem.ringtoneTime = oldTime;
			}
		} else {
			updateUI();
			saveChange();
		}
	}

	public void setVibrate() {
		String[] choices = new String[] {
				getResources().getString(R.string.yes),
				getResources().getString(R.string.no) };

		int checkedVibrate = 0;
		if (noteItem.clockItem.isVibrate) {
			checkedVibrate = 0;
		} else {
			checkedVibrate = 1;
		}
		new AlertDialog.Builder(AlarmActivity.this)
				.setTitle(R.string.setVibrate)
				// .setItems(yesOrNo, listener)
				.setSingleChoiceItems(choices, checkedVibrate, vibrateListener)
				.setNegativeButton(R.string.Cancel, cancelDialog).show();
	}

	OnClickListener vibrateListener = new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {
			// isVibrate = yesOrNo[which];
			// saveChange();
			// setListItem();
			switch (which) {
			case 0:
				noteItem.clockItem.isVibrate = true;
				break;
			case 1:
				noteItem.clockItem.isVibrate = false;
				break;
			}
			saveChange();
			dialog.dismiss();
			updateUI();
		}
	};
}