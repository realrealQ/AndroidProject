package com.way.note;

import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * ListView中每一行中包含的组件 这个类把ListView中的每一行都包装成一个ListItemView对象
 * 
 * @author way
 */
public final class ListItemView {
	public ViewGroup mLinearlayout;
	public TextView mLeftTextView;
	public TextView mRightTextView;
	public ImageView mRingtoneImage;
	public CheckBox mCheck;
}
